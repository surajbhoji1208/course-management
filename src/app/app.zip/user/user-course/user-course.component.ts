import { Component } from '@angular/core';

@Component({
  selector: 'app-user-course',
  standalone: false,
  templateUrl: './user-course.component.html',
  styleUrl: './user-course.component.css'
})
export class UserCourseComponent {

}
