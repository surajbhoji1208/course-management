//import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
//import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-userlayout',
  // imports: [CommonModule,RouterModule ],
  standalone: false,
  templateUrl: './userlayout.component.html',
  styleUrl: './userlayout.component.css'
})
export class UserlayoutComponent {

}
